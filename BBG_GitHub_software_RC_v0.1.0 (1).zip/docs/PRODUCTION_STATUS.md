# Reproducibility status

Present: selection script and cohort controller matching Step 33 server SHA-256, independent verification code, summary statistics.

Not yet included: `bbg96_finish_remaining.sh` exact executed wrapper, software environment lockfile, run commands and pilot concordance table to be extracted from Step 34 evidence. No claim of complete end-to-end reproducibility should be made until these are reviewed.

The sample crosswalk is a private institutional audit document and is not part of the public archive. Genotype-level data remain release-candidate only pending consent and data-release approval.
