# Release gates — public publication is not yet authorized

1. Confirm full manuscript authors/contributors, affiliations, ORCID identifiers, journal policies, and CITATION.cff authors.
2. Verify 22-animal institutional sample-to-library/BAM crosswalk and ethical/data-release authorization. Investigator has confirmed HiFi D01 corresponds to 803M/Illumina 803m; preserve supporting records privately.
3. Audit Step 34 archive: resource-controlled production runner, logged Paragraph command, environment versions, annotation GFF, exact 63-call matched-platform comparison.
4. Decide code/data licenses with rights holder and institution (MIT and CC BY 4.0 are **proposals**, not permissions).
5. Add original executed wrapper, environment specifications, complete versioned source and figure-generating scripts; note that original external software is not redistributed.
6. Reconfirm correctness of figures, sources, licensing and samples; do not commit raw BAM/FASTQ or personal sample crosswalk.
7. Once approved, remove release-candidate warnings, set accurate version, authors, license and future dataset/software DOI cross-links.
8. Publish a GitHub *release* only after enabling the new repository in Zenodo's GitHub integration; otherwise Zenodo will not automatically archive earlier releases.
