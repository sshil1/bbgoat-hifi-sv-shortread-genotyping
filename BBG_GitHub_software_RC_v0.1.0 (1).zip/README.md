# HiFi-informed SV genotyping in 22 Black Bengal goats — software companion

> **RELEASE CANDIDATE (not yet approved for public release).** Complete the source/documentation audit, confirm authorship and institutional data permissions, and use a private repository until approval.

## Scope

This is a **separate original-research extension**, not a replacement for the two-HiFi-genome Data Note. The discovery source reports 37,113 autosomal SVs in two individuals; this companion analyzes a selected 96-locus DEL/INS panel in 22 Illumina genomes. The user confirms **HiFi D01 = animal 803M**, represented as **803m** in the short-read cohort. The identity statement is provided by the investigator; underlying laboratory library crosswalk records are still required for the audit.

## Verified output snapshot (19 Nov 2026)

- 22 animals, 96 SV loci, 2,112 genotype attempts.
- 1,645 FT-PASS genotype calls; 1,632 with DP≥10.
- 52 loci with >=20 FT-PASS calls; 47 in the controller conservative set (five cross-platform-discordant loci excluded); 46 after the optional SV 0078 sensitivity exclusion.
- 39/47 conservative loci show multiple genotype states among callable calls.
- Exploratory locus-level Fisher test P=0.683264 (conservative DEL vs INS); stratified SV-length permutation P=0.075246 (20,000 permutations).
- SV 0078 has 22 heterozygous calls and a focal MAPQ-dependent coverage anomaly; its biological interpretation remains unresolved.

## Provenance

`src/bbg96_cohort.py` and `src/02_select_sv_pilot.py` are **byte-identical** to the versions inventoried on the GMBL server during Step 33 (SHA-256 checks in `docs/SOURCE_HASHES.tsv`). The resource-controlled `bbg96_finish_remaining.sh` and full executed Paragraph production logs are not yet included and require review of Step 34. Both scripts have environment-specific absolute paths and are **archival sources, not portable run instructions**.

`tools/verify_release.py` is a separate independent consistency validator, **not the original Paragraph implementation**. It uses only Python's standard library and tests the accompanying dataset's counts and SHA-256 manifests.

```bash
python3 tools/verify_release.py /path/to/unpacked/zenodo_dataset
```

## Data

The full 16-table 22-animal release candidate and six publication figures are provided separately as the Zenodo **dataset** upload package. `summary_tables/` contains only three small descriptive tables to ease browsing on GitHub. Do not put animal-identity crosswalks, personal identifiers, ethical correspondence or unpublished read access credentials in a public repository.

## Existing earlier resource

The independent two-HiFi-genome Data Note lists code at `https://github.com/sshil1/bbgoat-sv-scripts` and its software archive at DOI `10.5281/zenodo.24247314`. This separate extension must receive new repository/release identifiers and should cite that discovery resource appropriately, without reusing its DOI as the DOI of this study.

## Licensing and citation

Proposed code license: MIT; proposed data license: CC BY 4.0. **Neither has been approved for this separate study yet.** See `docs/RELEASE_GATES.md`. Update `CITATION.cff`, add approved LICENSE text, and confirm all contributors before creating a public GitHub release.
