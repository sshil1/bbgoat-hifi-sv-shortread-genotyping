#!/usr/bin/env python3
"""Independent, read-only invariants for the BBG 22-animal data package.

Usage: python3 tools/verify_release.py /path/to/unpacked/zenodo_dataset
Standard library only. No external computation, BAM access, or server mutations.
"""
import csv, hashlib, sys
from pathlib import Path
from collections import Counter, defaultdict

def read_tsv(p):
    with p.open(newline='',encoding='utf-8') as f:
        return list(csv.DictReader(f, delimiter='\t'))

def main():
    if len(sys.argv)!=2:
        raise SystemExit('USAGE: python3 tools/verify_release.py DATASET_DIRECTORY')
    root=Path(sys.argv[1])
    t=root/'tables'
    g=read_tsv(t/'cohort_genotypes_long.tsv')
    m=read_tsv(t/'BBG_22animal_manuscript_master_v1.tsv')
    s=read_tsv(t/'BBG_22animal_final_sensitivity_summary_v1.tsv')
    a=read_tsv(t/'BBG_22animal_final_analysis_sets_v1.tsv')
    p=read_tsv(t/'BBG_96SV_complete_source_provenance_audit.tsv')
    d=read_tsv(t/'BBG_0078_22animal_BAM_depth_audit_v1.tsv')
    assert len(g)==2112 and len(m)==96 and len(a)==96 and len(p)==96 and len(d)==22
    assert len({r['sample'] for r in g})==22
    assert len({(r['sample'],r['pilot_id']) for r in g})==2112
    assert {r['pilot_id'] for r in m} == {r['pilot_id'] for r in a}
    assert all(r['provenance_status']=='PASS' for r in p)
    assert sum(int(r['callable_ft_pass']) for r in g)==1645
    assert sum(int(r['callable_ft_pass']) and r['dp'].isdigit() and int(r['dp'])>=10 for r in g)==1632
    sets={r['analysis_set']:r for r in s}
    expect={'FT20_52':(52,42,10),'CONSERVATIVE_47':(47,39,8),'EXCLUDING_0078_46':(46,39,7)}
    for name, triple in expect.items():
        row=sets[name]
        actual=tuple(int(row[k]) for k in ('loci','variable_loci','uniform_loci'))
        assert actual==triple,(name,actual)
    for col,n in [('ft20_eligible',52),('conservative_eligible',47)]:
        assert sum(int(r[col]) for r in m)==n
    assert sum(r['paragraph_gt'].replace('|','/')=='0/1' for r in d)==22
    assert {r['pilot_id'] for r in m if r['ft20_eligible']=='1' and r['conservative_eligible']=='0'}=={
        'BBGSV_PILOT_0003','BBGSV_PILOT_0011','BBGSV_PILOT_0027','BBGSV_PILOT_0076','BBGSV_PILOT_0086'}
    # Verify shipped file manifest against all data files excluding itself.
    manifest=read_tsv(root/'SHA256_manifest.tsv')
    assert len(manifest)>=22
    assert len({r['relative_path'] for r in manifest})==len(manifest)
    for r in manifest:
        f=root/r['relative_path']
        assert f.is_file(),f
        h=hashlib.sha256(f.read_bytes()).hexdigest()
        assert h==r['sha256'],f
    print('BBG_DATASET_VALIDATION_PASS')
    print('GOATS=22 SV_LOCI=96 RECORDS=2112 FT_PASS=1645 FT_PASS_DP10=1632')
    print('FT20=52 CONSERVATIVE=47 EXCLUDING_0078=46 VARIABLE_CONSERVATIVE=39')
    print('SHA256_VERIFIED_FILES=',len(manifest))

if __name__=='__main__': main()
